package com.example.logdup;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.BlockRegistry;
import net.fabricmc.fabric.api.registry.ItemRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class LogDuplicationMod implements ModInitializer {
    public static final String MOD_ID = "logdup";
    
    // Block and Item declaration
    public static final Block LOG_DUPLICATION_TABLE = new LogDuplicationTableBlock();

    @Override
    public void onInitialize() {
        // Register block
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "log_duplication_table"), LOG_DUPLICATION_TABLE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "log_duplication_table"), new BlockItem(LOG_DUPLICATION_TABLE, new Item.Settings().group(ItemGroup.MISC)));
    }
}
