package com.example.logdup;

import net.minecraft.tileentity.TileEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModTileEntities {
    public static final DeferredRegister<TileEntityType<?>> TILE_ENTITIES = DeferredRegister.create(ForgeRegistries.TILE_ENTITIES, "logdup");

    public static final RegistryObject<TileEntityType<LogDuplicationTableTileEntity>> LOG_DUPLICATION_TABLE =
        TILE_ENTITIES.register("log_duplication_table", () -> TileEntityType.Builder.create(LogDuplicationTableTileEntity::new, LogDuplicationMod.LOG_DUPLICATION_TABLE).build(null));

    public static void register() {
        // Register tile entities
    }
}
