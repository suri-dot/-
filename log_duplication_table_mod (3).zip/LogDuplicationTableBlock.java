package com.example.logdup;

import net.minecraft.block.Block;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class LogDuplicationTableBlock extends Block {
    public LogDuplicationTableBlock() {
        super(AbstractBlock.Settings.copy(Blocks.CRAFTING_TABLE));
    }

    @Override
    public TileEntity createTileEntity(BlockState state, BlockView world) {
        return new LogDuplicationTableTileEntity();
    }
}
