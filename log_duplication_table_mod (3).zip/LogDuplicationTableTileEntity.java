package com.example.logdup;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class LogDuplicationTableTileEntity extends TileEntity {
    public LogDuplicationTableTileEntity() {
        super(ModTileEntities.LOG_DUPLICATION_TABLE.get());
    }

    public void duplicateItems() {
        // Logic to duplicate items
    }
}
